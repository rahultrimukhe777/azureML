import { ApplicationCustomizerContext } from "@microsoft/sp-application-base";
export interface CognitiveServiceConfiguration {
    context: ApplicationCustomizerContext;
}
export declare class CognitiveService {
    private context;
    private qnamakerEndpoint;
    private qnamakerEndpointKey;
    private knowledgebaseId;
    constructor(config: CognitiveServiceConfiguration);
    getQnaAnswer(userQuery: string): Promise<String>;
}
//# sourceMappingURL=cognitiveservices.d.ts.map