import { CognitiveService } from "../../../services/cognitiveservices";
export interface IFooterChatProps {
    cognitiveService: CognitiveService;
}
export interface IFooterChatState {
}
//# sourceMappingURL=IFooterChatProps.d.ts.map