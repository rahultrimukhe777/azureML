import * as React from 'react';
import { IFooterChatProps, IFooterChatState } from './IFooterChatProps';
import 'react-chat-widget/lib/styles.css';
export default class FooterChat extends React.Component<IFooterChatProps, IFooterChatState> {
    constructor(props: IFooterChatProps, state: IFooterChatState);
    componentDidMount(): void;
    private _handleNewUserMessage;
    render(): JSX.Element;
}
//# sourceMappingURL=FooterChat.d.ts.map