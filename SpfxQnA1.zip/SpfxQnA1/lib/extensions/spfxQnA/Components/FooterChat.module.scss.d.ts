declare const styles: {
    FooterChat: string;
};
export default styles;
//# sourceMappingURL=FooterChat.module.scss.d.ts.map