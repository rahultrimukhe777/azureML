import { HttpClient, IHttpClientOptions, HttpClientConfiguration } from "@microsoft/sp-http";
import { ApplicationCustomizerContext } from "@microsoft/sp-application-base";

export interface CognitiveServiceConfiguration {
    context: ApplicationCustomizerContext;
}

export class CognitiveService {
    private context: ApplicationCustomizerContext;
    private qnamakerEndpoint: string = "https://sharepointbotapp01.azurewebsites.net";
    private qnamakerEndpointKey: string = "2ae1cc2b-f80a-4a2d-9a3b-4d43087e7fdf";
    private knowledgebaseId: string = "c9943b2d-e8f0-4a6e-bd0e-2153a774e103";

    constructor(config: CognitiveServiceConfiguration) {
        this.context = config.context;
    }

    public async getQnaAnswer(userQuery: string): Promise<String> {
        let answer: string = 'Could not find the answer to your question... sorry!';
        // Build URI
        const postURL = this.qnamakerEndpoint + `/qnamaker/knowledgebases/${this.knowledgebaseId}/generateAnswer`;

        // Build body
        const body: string = JSON.stringify({
            'question': userQuery
        });

        // Build headers
        const requestHeaders: Headers = new Headers();
        requestHeaders.append('Content-type', 'application/json');
        requestHeaders.append('Authorization', this.qnamakerEndpointKey);

        const httpClientOptions: IHttpClientOptions = {
            body: body,
            headers: requestHeaders
        };

        let response = await this.context.httpClient.post(
            postURL,
            HttpClient.configurations.v1,
            httpClientOptions
        );

        if (response.ok) {
            let json = await response.json();
            if (json.answers[0].answer != 'No good match found in the KB')
                answer = json.answers[0].answer;
        }
        return answer;
    }
}