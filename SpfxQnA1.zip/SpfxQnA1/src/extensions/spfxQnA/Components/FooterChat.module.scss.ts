/* tslint:disable */
require("./FooterChat.module.css");
const styles = {
  FooterChat: 'FooterChat_688774a3'
};

export default styles;
/* tslint:enable */