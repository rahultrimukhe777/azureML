declare interface ISpfxQnAApplicationCustomizerStrings {
  Title: string;
  ChatTitle: string;
  ChatSubtitle: string;
}

declare module 'SpfxQnAApplicationCustomizerStrings' {
  const strings: ISpfxQnAApplicationCustomizerStrings;
  export = strings;
}
