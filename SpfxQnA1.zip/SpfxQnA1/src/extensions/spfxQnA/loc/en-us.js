define([], function() {
  return {
    "Title": "SpfxQnAApplicationCustomizer",
    "ChatTitle": "SharePoint Doubts",
    "ChatSubtitle": "Chatbot using MS Azure cognitive QandA services"
  }
});